 CREATE TABLE `test_transactions` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `reference` varchar(55) DEFAULT NULL,
 `method` varchar(15) DEFAULT NULL,
 `amount` decimal(10,2) DEFAULT NULL,
 `description` varchar(255) DEFAULT NULL,
 `status_code` int(11) NOT NULL DEFAULT '0',
 `status_message` varchar(255) DEFAULT NULL,
 `gateway_code` int(11) NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8
