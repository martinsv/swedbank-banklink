<?php
include '../setup.php';

use Swedbank\Banklink\Payment\InternetBank;
use Swedbank\Banklink\Payment\PayPal;
use Swedbank\Banklink\Payment\CreditCard;
use Swedbank\Banklink\Order;

$reference	 = filter_input(INPUT_GET, 'dts_reference');
$orderid	 = filter_input(INPUT_GET, '_merchantRef');
$status	 = filter_input(INPUT_GET, '_banklinkStatus');

$stmt	 = $db -> prepare("SELECT * FROM ".$test_table." WHERE id=?");
$stmt -> execute(array($orderid));
$row	 = $stmt -> fetch(PDO::FETCH_ASSOC);

if (!$reference) {
	$reference = $row['reference'];
}

$order = new Order($orderid, $row['description'], $row['amount'], $reference);

switch ($row['method']) {
	case 'internet': {
		$paymethod = new InternetBank('');
		break;
	}
	case 'paypal': {
		$paymethod = new PayPal();
		break;
	}
	case 'cc': {
		$paymethod = new CreditCard();
		break;
	}
}

$result = $gateway -> getStatus($order, $customer, $paymethod, $reference);

$stmt = $db -> prepare("UPDATE ".$test_table." SET status_code=?, status_message=?, gateway_code=? WHERE id = ?");
$stmt -> execute(array($result -> getStatus(), $result -> getMessage(), $result -> getRemoteStatus(), $orderid));

echo '<p>Result:</p>';
echo '<table border="1">';
echo '<tr><td>Success?</td><td>'.($result -> isSuccess() ? 'Y' : 'N').'</td></tr>';
echo '<tr><td>Status</td><td>'.($result -> getStatus()).'</td></tr>';
echo '<tr><td>Source</td><td>'.($result -> getSource()).'</td></tr>';
echo '<tr><td>Remote code</td><td>'.($result -> getRemoteStatus()).'</td></tr>';
echo '<tr><td>Message</td><td>'.($result -> getMessage()).'</td></tr>';
echo '<tr><td>Reference</td><td>'.($result -> getReference()).'</td></tr>';
echo '<tr><td>Instance</td><td>'.get_class($result).'</td></tr>';
echo '<tr><td>Raw data</td><td><pre>';
var_dump($result);
echo '</pre></td></tr>';
echo '<tr><td>Extended data</td><td><pre>';
var_dump($result -> getExtendedData());
echo '</pre></td></tr>';
echo '</table>';
