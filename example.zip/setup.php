<?php
/**
 * +------------------------------------------------------------+
 * |  DO NOT COPY WORKING EXAMPLE TO PRODUCTION ENVIRONMENT!!!  |
 * +------------------------------------------------------------+
 *
 * This file holds your test configuration.
 * For the sake of simplicity, this example is not the good practice to write code.
 */

include dirname(__FILE__).'/../vendor/autoload.php';
include dirname(__FILE__).'/vendor/autoload.php';

use \Monolog\Handler\StreamHandler;
use \Monolog\Logger;

use Swedbank\Banklink\Accreditation;
use Swedbank\Banklink\Gateway;
use Swedbank\Banklink\Merchant;
use Swedbank\Banklink\Customer;

/**
 * Just to see what's happening
 */
error_reporting(E_ALL);
ini_set('display_errors', true);

/**
 * Fill your configuration settings here.
 * See transaction_test.sql for testing table.
 */
$settings = [
	'mode' => Gateway::ENV_DEV,
	'region' => Gateway::REGION_LAT,
	'lang' => Gateway::LANG_LAT,
	'keys' => [
		'dev' => [
			'client' => 'DEV_USER',
			'pass' => 'DEV_PASS',
			'url' => 'DEV_LINK'
		],
		'prod' => [
			'client' => 'PROD_USER',
			'pass' => 'PROD_PASS',
			'url' => 'PROD_LINK'
		]
	],
	'db' => [
		'table' => 'test_transactions',
		'user' => 'root',
		'pass' => '',
		'host' => 'localhost',
		'name' => 'banklink'
	]
];

/**
 * +-------------------------------------------------------------+
 * |  No need to edit below if you configure $settings properly  |
 * +-------------------------------------------------------------+
 */
$dev = $settings['keys']['dev'];
$prod = $settings['keys']['prod'];

/**
 * Setup access
 */
$accreditation = new Accreditation();
$accreditation -> setDev($dev['client'], $dev['pass'], $dev['url']);
$accreditation -> setProd($prod['client'], $prod['pass'], $prod['url']);

/**
 * Configure merchant
 */
$merchant = new Merchant();
$merchant -> setRegion($settings['region']);
$merchant -> setLanguage($settings['lang']);

/**
 * Prepare gateway
 */

$gateway = new Gateway($accreditation, $merchant, $settings['mode']);

/**
 * Set event logging, if you need
 */
$logger = new Logger('transactions');
$logger -> pushHandler(new StreamHandler('transaction.log', Logger::DEBUG));
$gateway -> setLogger($logger);

/**
 * Test customer
 */
$customer = Customer::fromArray([
	'email' => 'armen.sokolov@example.com',
	'first_name' => 'Armen',
	'last_name' => 'Sokolov',
	'city' => 'Tammispea',
	'phone' => '+37261234567',
	'zip_code' => '74715',
	'address' => 'Lastekodu 2',
	'country' => 'EE'
]);

$db_acc = $settings['db'];
$test_table = $db_acc['table'];

$db = new PDO('mysql:host='.$db_acc['host'].';dbname='.$db_acc['name'].';charset=utf8mb4', $db_acc['user'], $db_acc['pass']);
